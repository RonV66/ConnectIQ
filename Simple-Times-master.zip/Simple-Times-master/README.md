# Simple Times
This is the repository for the Simple Times Analog watch face available on the Connect IQ Store.

https://apps.garmin.com/en-US/apps/6c46a9a1-3bd7-4d65-b7df-115e57d83abc

Please see the [Wiki page](https://github.com/winston-de/Simple-Times/wiki/Settings) for information on settings.