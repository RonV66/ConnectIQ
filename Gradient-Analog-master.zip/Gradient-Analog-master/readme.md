# Gradient Analog

This is the source code to the [Gradient Analog](https://apps.garmin.com/en-US/apps/43f188a5-e614-4dd5-84b9-5b839b1b6404) watch face. Although I am not actively maintaining this project, anyone is welcome to contribute.

![](https://services.garmin.com/appsLibraryBusinessServices_v0/rest/apps/43f188a5-e614-4dd5-84b9-5b839b1b6404/icon/f2af43da-7b5f-4406-a53d-306897c9038b)
